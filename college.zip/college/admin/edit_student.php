<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

if (!isset($_GET['id'])) {
    header("Location: students.php");
    exit;
}

$id = $_GET['id'];
$error = '';

// Fetch existing data
$stmt = $pdo->prepare("SELECT s.*, u.username FROM students s JOIN users u ON s.user_id = u.id WHERE s.id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) {
    header("Location: students.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $student_number = trim($_POST['student_number']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];

    if (empty($full_name) || empty($student_number)) {
        $error = "يرجى تعبئة الحقول الأساسية";
    } else {
        try {
            $pdo->beginTransaction();

            // Update User (Password if provided)
            if (!empty($password)) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->execute([$hashed_password, $student['user_id']]);
            }

            // Update Student Details
            $stmt = $pdo->prepare("UPDATE students SET student_number = ?, full_name = ?, email = ?, phone = ? WHERE id = ?");
            $stmt->execute([$student_number, $full_name, $email, $phone, $id]);

            $pdo->commit();
            header("Location: students.php?msg=تم تحديث بيانات الطالب بنجاح");
            exit;

        } catch (PDOException $e) {
            $pdo->rollBack();
            if ($e->getCode() == 23000) {
                $error = "الرقم الجامعي موجود مسبقاً";
            } else {
                $error = "حدث خطأ: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تعديل بيانات الطالب - ESAMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h3>ESAMS Admin</h3>
            <ul>
                <li><a href="dashboard.php">الرئيسية</a></li>
                <li><a href="students.php" class="active">إدارة الطلاب</a></li>
                <li><a href="courses.php">إدارة المواد</a></li>
                <li><a href="grades.php">رصد الدرجات</a></li>
                <li><a href="../auth/logout.php">تسجيل الخروج</a></li>
            </ul>
        </div>
        <div class="main-content">
            <h1>تعديل بيانات الطالب</h1>
            <div style="background: white; padding: 20px; border-radius: 8px; max-width: 600px;">
                <?php if ($error): ?>
                    <div class="error-msg"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="form-group">
                        <label>الاسم الكامل *</label>
                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($student['full_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>الرقم الجامعي *</label>
                        <input type="text" name="student_number" value="<?php echo htmlspecialchars($student['student_number']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>البريد الإلكتروني</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($student['email']); ?>">
                    </div>
                    <div class="form-group">
                        <label>رقم الهاتف</label>
                        <input type="text" name="phone" value="<?php echo htmlspecialchars($student['phone']); ?>">
                    </div>
                    <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
                    <div class="form-group">
                        <label>اسم المستخدم (لا يمكن تعديله)</label>
                        <input type="text" value="<?php echo htmlspecialchars($student['username']); ?>" disabled style="background: #f9f9f9;">
                    </div>
                    <div class="form-group">
                        <label>كلمة المرور الجديدة (اتركها فارغة إذا لم ترد التغيير)</label>
                        <input type="password" name="password" placeholder="********">
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">حفظ التعديلات</button>
                    <a href="students.php" class="btn btn-danger" style="width: 100%; text-align:center; margin-top:10px; box-sizing:border-box;">إلغاء</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
