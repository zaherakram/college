<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

// Fetch courses
$stmt = $pdo->query("SELECT * FROM courses ORDER BY created_at DESC");
$courses = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة المواد - ESAMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h3>ESAMS Admin</h3>
            <ul>
                <li><a href="dashboard.php">الرئيسية</a></li>
                <li><a href="students.php">إدارة الطلاب</a></li>
                <li><a href="courses.php" class="active">إدارة المواد</a></li>
                <li><a href="grades.php">رصد الدرجات</a></li>
                <li><a href="../auth/logout.php">تسجيل الخروج</a></li>
            </ul>
        </div>
        <div class="main-content">
            <h1>إدارة المواد الدراسية</h1>
            <a href="add_course.php" class="btn btn-primary" style="margin-bottom: 20px;">+ إضافة مادة جديدة</a>
            
            <?php if (isset($_GET['msg'])): ?>
                <div class="success-msg" style="background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
                    <?php echo htmlspecialchars($_GET['msg']); ?>
                </div>
            <?php endif; ?>

            <table>
                <thead>
                    <tr>
                        <th>رمز المادة</th>
                        <th>اسم المادة</th>
                        <th>الساعات المعتمدة</th>
                        <th>الوصف</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($courses as $course): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($course['course_code']); ?></td>
                        <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                        <td><?php echo htmlspecialchars($course['credit_hours']); ?></td>
                        <td><?php echo htmlspecialchars($course['description']); ?></td>
                        <td>
                            <a href="edit_course.php?id=<?php echo $course['id']; ?>" class="btn btn-primary">تعديل</a>
                            <a href="delete_course.php?id=<?php echo $course['id']; ?>" class="btn btn-danger" onclick="return confirm('هل أنت متأكد من الحذف؟');">حذف</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
