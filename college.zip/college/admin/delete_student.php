<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    try {
        // Need to delete the user record as well, which will cascade delete the student record due to FK constraints
        // Or finding the user_id first.
        $stmt = $pdo->prepare("SELECT user_id FROM students WHERE id = ?");
        $stmt->execute([$id]);
        $student = $stmt->fetch();
        
        if ($student) {
            $user_id = $student['user_id'];
            $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$user_id]); // This deletes from 'users'. 'students' record should delete via CASCADE if configured.
            // If my schema didn't have cascade on user deletion, I'd delete student first.
            // My schema: FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            // So deleting user is enough and better.
            
            header("Location: students.php?msg=تم حذف الطالب بنجاح");
        } else {
             header("Location: students.php?error=طالب غير موجود");
        }
    } catch (PDOException $e) {
        header("Location: students.php?error=فشل الحذف: " . $e->getMessage());
    }
} else {
    header("Location: students.php");
}
?>
