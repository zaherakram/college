<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM courses WHERE id = ?");
        $stmt->execute([$id]);
        header("Location: courses.php?msg=تم حذف المادة بنجاح");
    } catch (PDOException $e) {
        header("Location: courses.php?error=فشل الحذف: قد تكون المادة مرتبطة بسجلات طلاب");
    }
} else {
    header("Location: courses.php");
}
?>
