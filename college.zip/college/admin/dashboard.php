<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة تحكم المدير - ESAMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h3>ESAMS Admin</h3>
            <ul>
                <li><a href="dashboard.php" class="active">الرئيسية</a></li>
                <li><a href="students.php">إدارة الطلاب</a></li>
                <li><a href="courses.php">إدارة المواد</a></li>
                <li><a href="grades.php">رصد الدرجات</a></li>
                <li><a href="../auth/logout.php">تسجيل الخروج</a></li>
            </ul>
        </div>
        <div class="main-content">
            <h1>مرحباً بك، <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
            <p>هذه هي لوحة تحكم المدير.</p>
            <!-- Dashboard Widgets can go here -->
        </div>
    </div>
</body>
</html>
