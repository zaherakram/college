<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_code = trim($_POST['course_code']);
    $course_name = trim($_POST['course_name']);
    $credit_hours = (int)$_POST['credit_hours'];
    $description = trim($_POST['description']);

    if (empty($course_code) || empty($course_name) || empty($credit_hours)) {
        $error = "يرجى تعبئة الحقول الأساسية";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO courses (course_code, course_name, credit_hours, description) VALUES (?, ?, ?, ?)");
            $stmt->execute([$course_code, $course_name, $credit_hours, $description]);
            
            header("Location: courses.php?msg=تم إضافة المادة بنجاح");
            exit;

        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = "رمز المادة موجود مسبقاً";
            } else {
                $error = "حدث خطأ: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إضافة مادة جديدة - ESAMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h3>ESAMS Admin</h3>
            <ul>
                <li><a href="dashboard.php">الرئيسية</a></li>
                <li><a href="students.php">إدارة الطلاب</a></li>
                <li><a href="courses.php" class="active">إدارة المواد</a></li>
                <li><a href="grades.php">رصد الدرجات</a></li>
                <li><a href="../auth/logout.php">تسجيل الخروج</a></li>
            </ul>
        </div>
        <div class="main-content">
            <h1>إضافة مادة جديدة</h1>
            <div style="background: white; padding: 20px; border-radius: 8px; max-width: 600px;">
                <?php if ($error): ?>
                    <div class="error-msg"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="form-group">
                        <label>رمز المادة (مثال: CS101) *</label>
                        <input type="text" name="course_code" required>
                    </div>
                    <div class="form-group">
                        <label>اسم المادة *</label>
                        <input type="text" name="course_name" required>
                    </div>
                    <div class="form-group">
                        <label>الساعات المعتمدة *</label>
                        <input type="number" name="credit_hours" min="1" max="6" required>
                    </div>
                    <div class="form-group">
                        <label>وصف المادة</label>
                        <textarea name="description" rows="4" style="width: 100%; border: 1px solid #ddd; border-radius: 4px; padding: 10px;"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">حفظ المادة</button>
                    <a href="courses.php" class="btn btn-danger" style="width: 100%; text-align:center; margin-top:10px; box-sizing:border-box;">إلغاء</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
