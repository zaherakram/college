<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['grades'])) {
    $course_id = $_POST['course_id'];
    $grades = $_POST['grades'];

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("UPDATE enrollments SET grade = ? WHERE id = ?");
        foreach ($grades as $enrollment_id => $grade) {
            if ($grade !== '') {
                $stmt->execute([$grade, $enrollment_id]);
            }
        }
        $pdo->commit();
        header("Location: grades.php?course_id=$course_id&msg=تم حفظ الدرجات");
    } catch (Exception $e) {
        $pdo->rollBack();
        header("Location: grades.php?course_id=$course_id&error=حدث خطأ أثناء الحفظ");
    }
} else {
    header("Location: grades.php");
}
?>
