<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

$selected_course_id = isset($_GET['course_id']) ? $_GET['course_id'] : null;
$courses = $pdo->query("SELECT * FROM courses")->fetchAll();
$enrollments = [];

if ($selected_course_id) {
    $stmt = $pdo->prepare("
        SELECT e.id as enrollment_id, s.full_name, s.student_number, e.grade 
        FROM enrollments e 
        JOIN students s ON e.student_id = s.id 
        WHERE e.course_id = ?
    ");
    $stmt->execute([$selected_course_id]);
    $enrollments = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>رصد الدرجات - ESAMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h3>ESAMS Admin</h3>
            <ul>
                <li><a href="dashboard.php">الرئيسية</a></li>
                <li><a href="students.php">إدارة الطلاب</a></li>
                <li><a href="courses.php">إدارة المواد</a></li>
                <li><a href="grades.php" class="active">رصد الدرجات</a></li>
                <li><a href="../auth/logout.php">تسجيل الخروج</a></li>
            </ul>
        </div>
        <div class="main-content">
            <h1>رصد الدرجات</h1>
            
            <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <form method="GET">
                    <label>اختر المادة:</label>
                    <select name="course_id" onchange="this.form.submit()" style="padding: 10px; margin-right: 10px;">
                        <option value="">-- اختر المادة --</option>
                        <?php foreach ($courses as $course): ?>
                            <option value="<?php echo $course['id']; ?>" <?php echo ($selected_course_id == $course['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>

            <?php if ($selected_course_id): ?>
                <form action="submit_grades.php" method="POST">
                    <input type="hidden" name="course_id" value="<?php echo $selected_course_id; ?>">
                    <table>
                        <thead>
                            <tr>
                                <th>الرقم الجامعي</th>
                                <th>الاسم</th>
                                <th>الدرجة (من 100)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($enrollments) > 0): ?>
                                <?php foreach ($enrollments as $enrollment): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($enrollment['student_number']); ?></td>
                                    <td><?php echo htmlspecialchars($enrollment['full_name']); ?></td>
                                    <td>
                                        <input type="number" step="0.01" min="0" max="100" 
                                               name="grades[<?php echo $enrollment['enrollment_id']; ?>]" 
                                               value="<?php echo htmlspecialchars($enrollment['grade']); ?>" 
                                               style="width: 80px; padding: 5px;">
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="3" style="text-align:center;">لا يوجد طلاب مسجلين في هذه المادة</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php if (count($enrollments) > 0): ?>
                        <button type="submit" class="btn btn-primary" style="margin-top: 20px;">حفظ الدرجات</button>
                    <?php endif; ?>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
