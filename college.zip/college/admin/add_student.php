<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $student_number = trim($_POST['student_number']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($full_name) || empty($student_number) || empty($username) || empty($password)) {
        $error = "يرجى تعبئة الحقول الأساسية";
    } else {
        try {
            $pdo->beginTransaction();

            // 1. Create User
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'student')");
            $stmt->execute([$username, $hashed_password]);
            $user_id = $pdo->lastInsertId();

            // 2. Create Student Linked to User
            $stmt = $pdo->prepare("INSERT INTO students (user_id, student_number, full_name, email, phone) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $student_number, $full_name, $email, $phone]);

            $pdo->commit();
            header("Location: students.php?msg=تم إضافة الطالب بنجاح");
            exit;

        } catch (PDOException $e) {
            $pdo->rollBack();
            if ($e->getCode() == 23000) { // Duplicate entry
                $error = "اسم المستخدم أو الرقم الجامعي موجود مسبقاً";
            } else {
                $error = "حدث خطأ: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إضافة طالب جديد - ESAMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h3>ESAMS Admin</h3>
            <ul>
                <li><a href="dashboard.php">الرئيسية</a></li>
                <li><a href="students.php" class="active">إدارة الطلاب</a></li>
                <li><a href="courses.php">إدارة المواد</a></li>
                <li><a href="grades.php">رصد الدرجات</a></li>
                <li><a href="../auth/logout.php">تسجيل الخروج</a></li>
            </ul>
        </div>
        <div class="main-content">
            <h1>إضافة طالب جديد</h1>
            <div style="background: white; padding: 20px; border-radius: 8px; max-width: 600px;">
                <?php if ($error): ?>
                    <div class="error-msg"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="form-group">
                        <label>الاسم الكامل *</label>
                        <input type="text" name="full_name" required>
                    </div>
                    <div class="form-group">
                        <label>الرقم الجامعي *</label>
                        <input type="text" name="student_number" required>
                    </div>
                    <div class="form-group">
                        <label>البريد الإلكتروني</label>
                        <input type="email" name="email">
                    </div>
                    <div class="form-group">
                        <label>رقم الهاتف</label>
                        <input type="text" name="phone">
                    </div>
                    <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
                    <div class="form-group">
                        <label>اسم المستخدم (للدخول) *</label>
                        <input type="text" name="username" required>
                    </div>
                    <div class="form-group">
                        <label>كلمة المرور *</label>
                        <input type="password" name="password" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">حفظ الطالب</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
