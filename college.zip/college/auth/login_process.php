<?php
session_start();
require_once '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        header("Location: ../index.php?error=يرجى ملء جميع الحقول");
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();

        if ($user) {
            // In a real app, use password_verify($password, $user['password'])
            // For this project setup, we might have plain text or hashed.
            // Using password_verify for the default admin we inserted.
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                if ($user['role'] == 'admin') {
                    header("Location: ../admin/dashboard.php");
                } else {
                    header("Location: ../student/dashboard.php");
                }
                exit;
            } else {
                header("Location: ../index.php?error=كلمة المرور غير صحيحة");
                exit;
            }
        } else {
            header("Location: ../index.php?error=اسم المستخدم غير موجود");
            exit;
        }
    } catch (PDOException $e) {
        header("Location: ../index.php?error=حالة خطأ في النظام");
        exit;
    }
} else {
    header("Location: ../index.php");
    exit;
}
?>
