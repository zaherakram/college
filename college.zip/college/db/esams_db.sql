-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 25 يناير 2026 الساعة 09:54
-- إصدار الخادم: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esams_db`
--

-- --------------------------------------------------------

--
-- بنية الجدول `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `credit_hours` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `course_name`, `credit_hours`, `description`, `created_at`) VALUES
(1, 'CS101', 'مقدمة في الحاسب', 3, 'وصف توضيحي للمادة مقدمة في الحاسب', '2026-01-25 08:38:04'),
(2, 'CS102', 'برمجة 1', 4, 'وصف توضيحي للمادة برمجة 1', '2026-01-25 08:38:04'),
(3, 'CS201', 'برمجة 2', 4, 'وصف توضيحي للمادة برمجة 2', '2026-01-25 08:38:04'),
(4, 'IS201', 'أساسيات نظم المعلومات', 3, 'وصف توضيحي للمادة أساسيات نظم المعلومات', '2026-01-25 08:38:04'),
(5, 'CS204', 'تراكيب البيانات', 3, 'وصف توضيحي للمادة تراكيب البيانات', '2026-01-25 08:38:04'),
(6, 'CS301', 'نظم التشغيل', 3, 'وصف توضيحي للمادة نظم التشغيل', '2026-01-25 08:38:04'),
(7, 'CS305', 'الخوارزميات', 3, 'وصف توضيحي للمادة الخوارزميات', '2026-01-25 08:38:04'),
(8, 'IS321', 'قواعد البيانات', 3, 'وصف توضيحي للمادة قواعد البيانات', '2026-01-25 08:38:04'),
(9, 'CS351', 'هندسة البرمجيات', 3, 'وصف توضيحي للمادة هندسة البرمجيات', '2026-01-25 08:38:04'),
(10, 'CN311', 'شبكات الحاسب', 3, 'وصف توضيحي للمادة شبكات الحاسب', '2026-01-25 08:38:04'),
(11, 'IS401', 'إدارة مشاريع تقنية', 2, 'وصف توضيحي للمادة إدارة مشاريع تقنية', '2026-01-25 08:38:04'),
(12, 'CS410', 'الذكاء الاصطناعي', 3, 'وصف توضيحي للمادة الذكاء الاصطناعي', '2026-01-25 08:38:04'),
(13, 'CS420', 'أمن المعلومات', 3, 'وصف توضيحي للمادة أمن المعلومات', '2026-01-25 08:38:04'),
(14, 'IS450', 'تجارة إلكترونية', 2, 'وصف توضيحي للمادة تجارة إلكترونية', '2026-01-25 08:38:04'),
(15, 'GR101', 'مشروع تخرج 1', 3, 'وصف توضيحي للمادة مشروع تخرج 1', '2026-01-25 08:38:04'),
(16, 'cs1231', 'الرسم بالحاسوب', 3, '', '2026-01-25 08:40:32');

-- --------------------------------------------------------

--
-- بنية الجدول `enrollments`
--

CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `year` varchar(10) NOT NULL,
  `grade` decimal(5,2) DEFAULT NULL,
  `letter_grade` varchar(2) DEFAULT NULL,
  `status` enum('registered','completed','dropped') DEFAULT 'registered',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `enrollments`
--

INSERT INTO `enrollments` (`id`, `student_id`, `course_id`, `semester`, `year`, `grade`, `letter_grade`, `status`, `created_at`) VALUES
(1, 1, 7, 'First', '2026', 51.00, NULL, 'completed', '2026-01-25 08:38:04'),
(2, 1, 12, 'First', '2026', 92.00, NULL, 'completed', '2026-01-25 08:38:04'),
(3, 1, 4, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(4, 2, 3, 'First', '2026', 100.00, NULL, 'completed', '2026-01-25 08:38:04'),
(5, 2, 7, 'First', '2026', 54.00, NULL, 'completed', '2026-01-25 08:38:04'),
(6, 2, 12, 'First', '2026', 69.00, NULL, 'completed', '2026-01-25 08:38:04'),
(7, 2, 15, 'First', '2026', 84.00, NULL, 'completed', '2026-01-25 08:38:04'),
(8, 2, 14, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(9, 3, 2, 'First', '2026', 90.00, NULL, 'completed', '2026-01-25 08:38:04'),
(10, 3, 13, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(11, 3, 4, 'First', '2026', 83.00, NULL, 'completed', '2026-01-25 08:38:04'),
(12, 3, 8, 'First', '2026', 70.00, NULL, 'completed', '2026-01-25 08:38:04'),
(13, 4, 2, 'First', '2026', 94.00, NULL, 'completed', '2026-01-25 08:38:04'),
(14, 4, 5, 'First', '2026', 89.00, NULL, 'completed', '2026-01-25 08:38:04'),
(15, 4, 14, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(16, 5, 2, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(17, 5, 12, 'First', '2026', 83.00, NULL, 'completed', '2026-01-25 08:38:04'),
(18, 5, 15, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(19, 5, 14, 'First', '2026', 76.00, NULL, 'completed', '2026-01-25 08:38:04'),
(20, 6, 10, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(21, 6, 3, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(22, 6, 5, 'First', '2026', 63.00, NULL, 'completed', '2026-01-25 08:38:04'),
(23, 6, 11, 'First', '2026', 95.00, NULL, 'completed', '2026-01-25 08:38:04'),
(24, 7, 10, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(25, 7, 1, 'First', '2026', 62.00, NULL, 'completed', '2026-01-25 08:38:04'),
(26, 7, 9, 'First', '2026', 66.00, NULL, 'completed', '2026-01-25 08:38:04'),
(27, 7, 14, 'First', '2026', 62.00, NULL, 'completed', '2026-01-25 08:38:04'),
(28, 8, 5, 'First', '2026', 58.00, NULL, 'completed', '2026-01-25 08:38:04'),
(29, 8, 6, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(30, 8, 9, 'First', '2026', 86.00, NULL, 'completed', '2026-01-25 08:38:04'),
(31, 8, 12, 'First', '2026', 100.00, NULL, 'completed', '2026-01-25 08:38:04'),
(32, 9, 10, 'First', '2026', 66.00, NULL, 'completed', '2026-01-25 08:38:04'),
(33, 9, 2, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(34, 9, 3, 'First', '2026', 77.00, NULL, 'completed', '2026-01-25 08:38:04'),
(35, 9, 9, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(36, 10, 10, 'First', '2026', 91.00, NULL, 'completed', '2026-01-25 08:38:04'),
(37, 10, 2, 'First', '2026', 95.00, NULL, 'completed', '2026-01-25 08:38:04'),
(38, 10, 6, 'First', '2026', 80.00, NULL, 'completed', '2026-01-25 08:38:04'),
(39, 10, 14, 'First', '2026', 60.00, NULL, 'completed', '2026-01-25 08:38:04'),
(40, 11, 1, 'First', '2026', 77.00, NULL, 'registered', '2026-01-25 08:38:04'),
(41, 11, 6, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(42, 11, 9, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(43, 11, 13, 'First', '2026', 98.00, NULL, 'completed', '2026-01-25 08:38:04'),
(44, 11, 15, 'First', '2026', 94.00, NULL, 'completed', '2026-01-25 08:38:04'),
(45, 11, 8, 'First', '2026', 66.00, NULL, 'completed', '2026-01-25 08:38:04'),
(46, 12, 1, 'First', '2026', 82.00, NULL, 'completed', '2026-01-25 08:38:04'),
(47, 12, 6, 'First', '2026', 51.00, NULL, 'completed', '2026-01-25 08:38:04'),
(48, 12, 9, 'First', '2026', 54.00, NULL, 'completed', '2026-01-25 08:38:04'),
(49, 12, 13, 'First', '2026', 60.00, NULL, 'completed', '2026-01-25 08:38:04'),
(50, 12, 4, 'First', '2026', 68.00, NULL, 'completed', '2026-01-25 08:38:04'),
(51, 12, 11, 'First', '2026', 51.00, NULL, 'completed', '2026-01-25 08:38:04'),
(52, 13, 3, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(53, 13, 9, 'First', '2026', 55.00, NULL, 'completed', '2026-01-25 08:38:04'),
(54, 13, 13, 'First', '2026', 87.00, NULL, 'completed', '2026-01-25 08:38:04'),
(55, 14, 1, 'First', '2026', 94.00, NULL, 'completed', '2026-01-25 08:38:04'),
(56, 14, 5, 'First', '2026', 73.00, NULL, 'completed', '2026-01-25 08:38:04'),
(57, 14, 6, 'First', '2026', NULL, NULL, 'registered', '2026-01-25 08:38:04'),
(58, 14, 12, 'First', '2026', 74.00, NULL, 'completed', '2026-01-25 08:38:04'),
(59, 15, 1, 'First', '2026', 77.00, NULL, 'completed', '2026-01-25 08:38:04'),
(60, 15, 3, 'First', '2026', 74.00, NULL, 'completed', '2026-01-25 08:38:04'),
(61, 15, 6, 'First', '2026', 91.00, NULL, 'completed', '2026-01-25 08:38:04'),
(62, 15, 11, 'First', '2026', 65.00, NULL, 'completed', '2026-01-25 08:38:04'),
(63, 17, 1, 'First', '2026', 94.00, NULL, 'registered', '2026-01-25 08:41:27'),
(64, 17, 2, 'First', '2026', 90.00, NULL, 'registered', '2026-01-25 08:41:28'),
(65, 17, 3, 'First', '2026', 88.00, NULL, 'registered', '2026-01-25 08:41:29');

-- --------------------------------------------------------

--
-- بنية الجدول `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `student_number` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `students`
--

INSERT INTO `students` (`id`, `user_id`, `student_number`, `full_name`, `email`, `phone`) VALUES
(1, 2, '43972919', 'محمد الزهراني', 'student1@college.edu.sa', '0523668227'),
(2, 3, '44155287', 'فاطمة الزهراني', 'student2@college.edu.sa', '0514442608'),
(3, 4, '43028051', 'يوسف القحطاني', 'student3@college.edu.sa', '0580009631'),
(4, 5, '44544839', 'محمد القحطاني', 'student4@college.edu.sa', '0523414977'),
(5, 6, '44318899', 'محمد السبيعي', 'student5@college.edu.sa', '0524945803'),
(6, 7, '44261843', 'محمد السبيعي', 'student6@college.edu.sa', '0573208822'),
(7, 8, '43624038', 'محمد الغامدي', 'student7@college.edu.sa', '0563848804'),
(8, 9, '44411538', 'نايف الحربي', 'student8@college.edu.sa', '0516332220'),
(9, 10, '44275819', 'سارة السبيعي', 'student9@college.edu.sa', '0561543282'),
(10, 11, '43828237', 'خالد الغامدي', 'student10@college.edu.sa', '0542997279'),
(11, 12, '43514363', 'خالد الدوسري', 'student11@college.edu.sa', '0565336580'),
(12, 13, '43886619', 'منى الشهري', 'student12@college.edu.sa', '0526733052'),
(13, 14, '44342766', 'سارة الدوسري', 'student13@college.edu.sa', '0546588432'),
(14, 15, '43670161', 'محمد العمري', 'student14@college.edu.sa', '0513139522'),
(15, 16, '44041670', 'عمر القحطاني', 'student15@college.edu.sa', '0578509567'),
(17, 18, '44041330', '‪ghassan saqer‬‏', 'ghassan.saqer.1996@gmail.com', '0595000005');

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','student') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`) VALUES
(1, 'admin', '$2y$10$bC9DMRDHVQ4qhMECgpETQO6JnRMEhjZangDfHe/clIcaojqbNT82W', 'admin', '2026-01-25 08:31:05'),
(2, 'student1', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(3, 'student2', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(4, 'student3', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(5, 'student4', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(6, 'student5', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(7, 'student6', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(8, 'student7', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(9, 'student8', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(10, 'student9', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(11, 'student10', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(12, 'student11', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(13, 'student12', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(14, 'student13', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(15, 'student14', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(16, 'student15', '$2y$10$r7Gkmvi3jA3IFLZPAFXKt.GVXe24UBslLetlVX/j205WnymJ7ZRKy', 'student', '2026-01-25 08:38:04'),
(18, 'admin@123.com', '$2y$10$KtDXdflulKDHJmtB.mGMeeSXo0Fbssy3ukfsPXa4fWWaGa0e7cVu.', 'student', '2026-01-25 08:41:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `course_code` (`course_code`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_number` (`student_number`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- قيود الجداول المُلقاة.
--

--
-- قيود الجداول `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
