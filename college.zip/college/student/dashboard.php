<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>بوابة الطالب - ESAMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h3>بوابة الطالب</h3>
            <ul>
                <li><a href="dashboard.php" class="active">الرئيسية</a></li>
                <li><a href="register.php">تسجيل المواد</a></li>
                <li><a href="schedule.php">جدولي الدراسي</a></li>
                <li><a href="grades.php">كشف الدرجات</a></li>
                <li><a href="../auth/logout.php">تسجيل الخروج</a></li>
            </ul>
        </div>
        <div class="main-content">
            <h1>مرحباً بك، <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
            <p>أهلاً بك في بوابة الطالب.</p>
        </div>
    </div>
</body>
</html>
