<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT id FROM students WHERE user_id = ?");
$stmt->execute([$user_id]);
$student = $stmt->fetch();
$student_id = $student['id'];

// Get registered courses
$stmt = $pdo->prepare("
    SELECT c.*, e.semester 
    FROM enrollments e 
    JOIN courses c ON e.course_id = c.id 
    WHERE e.student_id = ?
");
$stmt->execute([$student_id]);
$my_courses = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>جدولي الدراسي - ESAMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h3>بوابة الطالب</h3>
            <ul>
                <li><a href="dashboard.php">الرئيسية</a></li>
                <li><a href="register.php">تسجيل المواد</a></li>
                <li><a href="schedule.php" class="active">جدولي الدراسي</a></li>
                <li><a href="grades.php">كشف الدرجات</a></li>
                <li><a href="../auth/logout.php">تسجيل الخروج</a></li>
            </ul>
        </div>
        <div class="main-content">
            <h1>المواد المسجلة</h1>
            <table>
                <thead>
                    <tr>
                        <th>رمز المادة</th>
                        <th>اسم المادة</th>
                        <th>الساعات</th>
                        <th>الفصل الدراسي</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($my_courses) > 0): ?>
                        <?php foreach ($my_courses as $course): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($course['course_code']); ?></td>
                            <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                            <td><?php echo htmlspecialchars($course['credit_hours']); ?></td>
                            <td><?php echo htmlspecialchars($course['semester']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="4" style="text-align:center;">لم تقم بتسجيل أي مواد بعد</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
