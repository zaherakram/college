<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

$user_id = $_SESSION['user_id'];
// Get student ID
$stmt = $pdo->prepare("SELECT id FROM students WHERE user_id = ?");
$stmt->execute([$user_id]);
$student = $stmt->fetch();
$student_id = $student['id'];

// Get all courses
$courses = $pdo->query("SELECT * FROM courses")->fetchAll();

// Get registered courses
$stmt = $pdo->prepare("SELECT course_id FROM enrollments WHERE student_id = ?");
$stmt->execute([$student_id]);
$registered_courses = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Handle Registration
if (isset($_GET['register'])) {
    $course_id_to_register = $_GET['register'];
    if (!in_array($course_id_to_register, $registered_courses)) {
        $stmt = $pdo->prepare("INSERT INTO enrollments (student_id, course_id, semester, year) VALUES (?, ?, 'First', '2026')");
        $stmt->execute([$student_id, $course_id_to_register]);
        header("Location: register.php?msg=تم تسجيل المادة بنجاح");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تسجيل المواد - ESAMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h3>بوابة الطالب</h3>
            <ul>
                <li><a href="dashboard.php">الرئيسية</a></li>
                <li><a href="register.php" class="active">تسجيل المواد</a></li>
                <li><a href="schedule.php">جدولي الدراسي</a></li>
                <li><a href="grades.php">كشف الدرجات</a></li>
                <li><a href="../auth/logout.php">تسجيل الخروج</a></li>
            </ul>
        </div>
        <div class="main-content">
            <h1>تسجيل المواد المتاحة</h1>
            <?php if (isset($_GET['msg'])): ?>
                <div class="success-msg" style="background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
                    <?php echo htmlspecialchars($_GET['msg']); ?>
                </div>
            <?php endif; ?>

            <table>
                <thead>
                    <tr>
                        <th>رمز المادة</th>
                        <th>اسم المادة</th>
                        <th>الساعات</th>
                        <th>الحالة</th>
                        <th>الإجراء</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($courses as $course): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($course['course_code']); ?></td>
                        <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                        <td><?php echo htmlspecialchars($course['credit_hours']); ?></td>
                        <td>
                            <?php if (in_array($course['id'], $registered_courses)): ?>
                                <span style="color: green; font-weight: bold;">مسجل</span>
                            <?php else: ?>
                                <span style="color: grey;">غير مسجل</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!in_array($course['id'], $registered_courses)): ?>
                                <a href="register.php?register=<?php echo $course['id']; ?>" class="btn btn-primary">تسجيل</a>
                            <?php else: ?>
                                <button class="btn" disabled style="background: #ccc; cursor: not-allowed;">مسجل</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
