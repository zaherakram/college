<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../index.php");
    exit;
}
require_once '../includes/db.php';

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT id FROM students WHERE user_id = ?");
$stmt->execute([$user_id]);
$student = $stmt->fetch();
$student_id = $student['id'];

// Get grades
$stmt = $pdo->prepare("
    SELECT c.course_code, c.course_name, c.credit_hours, e.grade 
    FROM enrollments e 
    JOIN courses c ON e.course_id = c.id 
    WHERE e.student_id = ? AND e.grade IS NOT NULL
");
$stmt->execute([$student_id]);
$grades = $stmt->fetchAll();

// Calculate GPA (Simple version)
$total_points = 0;
$total_hours = 0;
foreach ($grades as $g) {
    if ($g['grade'] >= 60) { // Assuming 60 is pass
        // Convert percentage to 4.0 scale (approx)
        $points = ($g['grade'] / 20) - 1; 
        if ($points < 1) $points = 0; // Fail
    } else {
        $points = 0;
    }
    // Or just use percentage average if not strictly GPA
    $total_points += $g['grade'] * $g['credit_hours'];
    $total_hours += $g['credit_hours'];
}
$gpa = ($total_hours > 0) ? round($total_points / $total_hours, 2) : 0;
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>كشف الدرجات - ESAMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="sidebar">
            <h3>بوابة الطالب</h3>
            <ul>
                <li><a href="dashboard.php">الرئيسية</a></li>
                <li><a href="register.php">تسجيل المواد</a></li>
                <li><a href="schedule.php">جدولي الدراسي</a></li>
                <li><a href="grades.php" class="active">كشف الدرجات</a></li>
                <li><a href="../auth/logout.php">تسجيل الخروج</a></li>
            </ul>
        </div>
        <div class="main-content">
            <h1>كشف الدرجات</h1>
            
            <div style="background: #2c3e50; color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h3>المعدل الفصلي (Average): <?php echo $gpa; ?>%</h3>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>رمز المادة</th>
                        <th>اسم المادة</th>
                        <th>الساعات</th>
                        <th>الدرجة</th>
                        <th>التقدير</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($grades) > 0): ?>
                        <?php foreach ($grades as $grade): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($grade['course_code']); ?></td>
                            <td><?php echo htmlspecialchars($grade['course_name']); ?></td>
                            <td><?php echo htmlspecialchars($grade['credit_hours']); ?></td>
                            <td><?php echo htmlspecialchars($grade['grade']); ?></td>
                            <td>
                                <?php 
                                    $g = $grade['grade'];
                                    if ($g >= 90) echo "ممتاز";
                                    elseif ($g >= 80) echo "جيد جداً";
                                    elseif ($g >= 70) echo "جيد";
                                    elseif ($g >= 60) echo "مقبول";
                                    else echo "راسب";
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="5" style="text-align:center;">لم يتم رصد درجات بعد</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
